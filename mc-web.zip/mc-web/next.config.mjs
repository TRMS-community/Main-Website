/** @type {import('next').NextConfig} */
const nextConfig = {
    images: {
      domains: ['wallpapercave.com' , 'crafatar.com'], // Specify the allowed domain
    },
  };
  
  export default nextConfig;
  