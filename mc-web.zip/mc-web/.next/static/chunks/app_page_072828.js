(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_072828.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_072828.js",
  "chunks": [
    "static/chunks/node_modules_next_0766a2._.js",
    "static/chunks/node_modules_framer-motion_dist_es_ec36d6._.js",
    "static/chunks/node_modules_c60444._.js",
    "static/chunks/_cd9374._.js"
  ],
  "source": "dynamic"
});
